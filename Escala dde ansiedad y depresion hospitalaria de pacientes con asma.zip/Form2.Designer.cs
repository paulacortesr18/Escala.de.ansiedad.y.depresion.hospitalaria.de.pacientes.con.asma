﻿namespace APP_HAS
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Location = new System.Drawing.Point(25, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Me siento tenso o nervioso";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Location = new System.Drawing.Point(9, 180);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(355, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Tengo una sensación de miedo, como s algo horrible me fuera a suceder ";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label7.Location = new System.Drawing.Point(626, 175);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(269, 15);
            this.label7.TabIndex = 6;
            this.label7.Text = "Puedo estar sentado tranquilamente y sentirme relajado";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label13.Location = new System.Drawing.Point(374, 40);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(204, 15);
            this.label13.TabIndex = 12;
            this.label13.Text = "Tengo mi mente llena de preocupaciones";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label15.Location = new System.Drawing.Point(845, 42);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(272, 15);
            this.label15.TabIndex = 14;
            this.label15.Text = "Me siento inquieto como si no fuera capaz de moverme ";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(9, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(852, 23);
            this.button1.TabIndex = 35;
            this.button1.Text = "ANSIEDAD";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label11.Location = new System.Drawing.Point(9, 269);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(224, 15);
            this.label11.TabIndex = 48;
            this.label11.Text = "Me asaltan sentimeintos repentinos de pánico";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(186, 34);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(70, 20);
            this.textBox4.TabIndex = 52;
            this.textBox4.Text = "Nunca ";
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(186, 117);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(85, 20);
            this.textBox5.TabIndex = 53;
            this.textBox5.Text = "Todos los Días";
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(186, 87);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(85, 20);
            this.textBox6.TabIndex = 54;
            this.textBox6.Text = "Muchas Veces";
            this.textBox6.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(307, 37);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(34, 20);
            this.textBox7.TabIndex = 55;
            this.textBox7.Text = "0";
            this.textBox7.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(408, 175);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(77, 20);
            this.textBox8.TabIndex = 57;
            this.textBox8.Text = "Nada";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(584, 113);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(145, 20);
            this.textBox9.TabIndex = 58;
            this.textBox9.Text = "La mayoría de las veces ";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(186, 61);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(70, 20);
            this.textBox11.TabIndex = 60;
            this.textBox11.Text = "A veces ";
            this.textBox11.TextChanged += new System.EventHandler(this.textBox11_TextChanged);
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(584, 40);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 20);
            this.textBox12.TabIndex = 61;
            this.textBox12.Text = "Solo en  ocasiones ";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(584, 66);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(188, 20);
            this.textBox13.TabIndex = 62;
            this.textBox13.Text = "A veces, aunque no muy a menudo";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(584, 87);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(136, 20);
            this.textBox14.TabIndex = 63;
            this.textBox14.Text = "Con bastante frecuencia";
            this.textBox14.TextChanged += new System.EventHandler(this.textBox14_TextChanged);
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(913, 175);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(100, 20);
            this.textBox15.TabIndex = 64;
            this.textBox15.Text = "Siempre";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(913, 201);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(100, 20);
            this.textBox16.TabIndex = 65;
            this.textBox16.Text = "Por lo general";
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(913, 227);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(100, 20);
            this.textBox17.TabIndex = 66;
            this.textBox17.Text = "No muy a menudo";
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(242, 279);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(100, 20);
            this.textBox18.TabIndex = 67;
            this.textBox18.Text = "Siemprs";
            this.textBox18.TextChanged += new System.EventHandler(this.textBox18_TextChanged);
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(242, 305);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(100, 20);
            this.textBox19.TabIndex = 68;
            this.textBox19.Text = "Por lo general ";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(307, 61);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(34, 20);
            this.textBox1.TabIndex = 69;
            this.textBox1.Text = "1";
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(307, 87);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(34, 20);
            this.textBox2.TabIndex = 70;
            this.textBox2.Text = "2";
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged_1);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(307, 117);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(34, 20);
            this.textBox3.TabIndex = 71;
            this.textBox3.Text = "3";
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(396, 201);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(143, 20);
            this.textBox10.TabIndex = 72;
            this.textBox10.Text = "Un poco, pero me preocupa";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(396, 227);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(143, 20);
            this.textBox20.TabIndex = 73;
            this.textBox20.Text = "Si, pero no es muy fuerte";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(376, 252);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(163, 20);
            this.textBox21.TabIndex = 74;
            this.textBox21.Text = "Definitivamene, ya es muy fuerte";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(565, 175);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(34, 20);
            this.textBox22.TabIndex = 75;
            this.textBox22.Text = "0";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(565, 201);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(34, 20);
            this.textBox23.TabIndex = 76;
            this.textBox23.Text = "1";
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(565, 227);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(34, 20);
            this.textBox24.TabIndex = 77;
            this.textBox24.Text = "2";
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(565, 252);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(34, 20);
            this.textBox25.TabIndex = 78;
            this.textBox25.Text = "3";
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(241, 331);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(100, 20);
            this.textBox26.TabIndex = 79;
            this.textBox26.Text = "No muy a menudo";
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(242, 357);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(100, 20);
            this.textBox27.TabIndex = 80;
            this.textBox27.Text = "Nunca";
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(356, 279);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(34, 20);
            this.textBox28.TabIndex = 81;
            this.textBox28.Text = "0";
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(356, 305);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(34, 20);
            this.textBox29.TabIndex = 82;
            this.textBox29.Text = "1";
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(356, 331);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(34, 20);
            this.textBox30.TabIndex = 83;
            this.textBox30.Text = "2";
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(356, 357);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(34, 20);
            this.textBox31.TabIndex = 84;
            this.textBox31.Text = "3";
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(782, 37);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(34, 20);
            this.textBox32.TabIndex = 85;
            this.textBox32.Text = "0";
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(782, 61);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(34, 20);
            this.textBox33.TabIndex = 86;
            this.textBox33.Text = "1";
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(782, 87);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(34, 20);
            this.textBox34.TabIndex = 87;
            this.textBox34.Text = "2";
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(1030, 253);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(34, 20);
            this.textBox35.TabIndex = 88;
            this.textBox35.Text = "3";
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(782, 117);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(34, 20);
            this.textBox36.TabIndex = 89;
            this.textBox36.Text = "3";
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(913, 253);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(100, 20);
            this.textBox37.TabIndex = 90;
            this.textBox37.Text = "Nunca";
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(1030, 175);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(34, 20);
            this.textBox38.TabIndex = 91;
            this.textBox38.Text = "0";
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(1030, 201);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(34, 20);
            this.textBox39.TabIndex = 92;
            this.textBox39.Text = "1";
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(1030, 227);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(34, 20);
            this.textBox40.TabIndex = 93;
            this.textBox40.Text = "2";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label9.Location = new System.Drawing.Point(437, 310);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(311, 15);
            this.label9.TabIndex = 94;
            this.label9.Text = "Tengo una sensación extraña como de \"aleteo\" en el estomago";
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(761, 307);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(100, 20);
            this.textBox41.TabIndex = 95;
            this.textBox41.Text = "Nunca";
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(754, 331);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(116, 20);
            this.textBox42.TabIndex = 96;
            this.textBox42.Text = "En ciertas ocasiones";
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(754, 357);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(128, 20);
            this.textBox43.TabIndex = 97;
            this.textBox43.Text = "Con bastante frecuencia";
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(754, 383);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(128, 20);
            this.textBox44.TabIndex = 98;
            this.textBox44.Text = "Muy a menudo";
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(888, 307);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(34, 20);
            this.textBox45.TabIndex = 99;
            this.textBox45.Text = "0";
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(888, 331);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(34, 20);
            this.textBox46.TabIndex = 100;
            this.textBox46.Text = "1";
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(888, 357);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(34, 20);
            this.textBox47.TabIndex = 101;
            this.textBox47.Text = "2";
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(888, 383);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(34, 20);
            this.textBox48.TabIndex = 102;
            this.textBox48.Text = "3";
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(1132, 40);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(100, 20);
            this.textBox49.TabIndex = 103;
            this.textBox49.Text = "Nada";
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(1132, 66);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(100, 20);
            this.textBox50.TabIndex = 104;
            this.textBox50.Text = "No mucho";
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(1132, 92);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(100, 20);
            this.textBox51.TabIndex = 105;
            this.textBox51.Text = "Bastante";
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(1132, 118);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(100, 20);
            this.textBox52.TabIndex = 106;
            this.textBox52.Text = "Mucho";
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(1238, 42);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(34, 20);
            this.textBox53.TabIndex = 107;
            this.textBox53.Text = "0";
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(1238, 68);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(34, 20);
            this.textBox54.TabIndex = 108;
            this.textBox54.Text = "1";
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(1238, 94);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(34, 20);
            this.textBox55.TabIndex = 109;
            this.textBox55.Text = "2";
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(1238, 120);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(34, 20);
            this.textBox56.TabIndex = 110;
            this.textBox56.Text = "3";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(522, 278);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 111;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(307, 383);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 112;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(256, 143);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 21);
            this.comboBox3.TabIndex = 113;
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(733, 137);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(121, 21);
            this.comboBox4.TabIndex = 114;
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(845, 409);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(121, 21);
            this.comboBox5.TabIndex = 115;
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(960, 279);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(121, 21);
            this.comboBox6.TabIndex = 116;
            // 
            // comboBox7
            // 
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Location = new System.Drawing.Point(1170, 155);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(121, 21);
            this.comboBox7.TabIndex = 117;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1103, 312);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 13);
            this.label2.TabIndex = 118;
            this.label2.Text = "RESULTADO";
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(1078, 328);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(139, 20);
            this.textBox57.TabIndex = 119;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1347, 455);
            this.Controls.Add(this.textBox57);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBox7);
            this.Controls.Add(this.comboBox6);
            this.Controls.Add(this.comboBox5);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox56);
            this.Controls.Add(this.textBox55);
            this.Controls.Add(this.textBox54);
            this.Controls.Add(this.textBox53);
            this.Controls.Add(this.textBox52);
            this.Controls.Add(this.textBox51);
            this.Controls.Add(this.textBox50);
            this.Controls.Add(this.textBox49);
            this.Controls.Add(this.textBox48);
            this.Controls.Add(this.textBox47);
            this.Controls.Add(this.textBox46);
            this.Controls.Add(this.textBox45);
            this.Controls.Add(this.textBox44);
            this.Controls.Add(this.textBox43);
            this.Controls.Add(this.textBox42);
            this.Controls.Add(this.textBox41);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBox40);
            this.Controls.Add(this.textBox39);
            this.Controls.Add(this.textBox38);
            this.Controls.Add(this.textBox37);
            this.Controls.Add(this.textBox36);
            this.Controls.Add(this.textBox35);
            this.Controls.Add(this.textBox34);
            this.Controls.Add(this.textBox33);
            this.Controls.Add(this.textBox32);
            this.Controls.Add(this.textBox31);
            this.Controls.Add(this.textBox30);
            this.Controls.Add(this.textBox29);
            this.Controls.Add(this.textBox28);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.textBox25);
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.Text = "Evaluacion Mental";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox57;
    }
}