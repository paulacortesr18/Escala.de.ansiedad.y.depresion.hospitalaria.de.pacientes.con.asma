﻿namespace APP_HAS
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button2 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(58, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(697, 23);
            this.button2.TabIndex = 37;
            this.button2.Text = "DEPRESIÓN";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label8.Location = new System.Drawing.Point(436, 313);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(237, 15);
            this.label8.TabIndex = 41;
            this.label8.Text = "Me siento como si cada día  estuviera más lento";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label6.Location = new System.Drawing.Point(68, 308);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 15);
            this.label6.TabIndex = 40;
            this.label6.Text = "Me siento alegre";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Location = new System.Drawing.Point(53, 190);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(235, 15);
            this.label2.TabIndex = 38;
            this.label2.Text = "Puedo reirme y ver el lado positivo de las cosas ";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label18.Location = new System.Drawing.Point(1027, 54);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(320, 15);
            this.label18.TabIndex = 53;
            this.label18.Text = "Me diivierto con un buen libro, la radio y un programa de televisión";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label16.Location = new System.Drawing.Point(543, 187);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(184, 15);
            this.label16.TabIndex = 52;
            this.label16.Text = "Me siento optimista respecto al futuro";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Location = new System.Drawing.Point(58, 59);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(230, 15);
            this.label4.TabIndex = 50;
            this.label4.Text = "Todavía disfruto con lo que antes me gustaba ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label10.Location = new System.Drawing.Point(503, 59);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(213, 15);
            this.label10.TabIndex = 54;
            this.label10.Text = "He perdido interés por mi aspecto personal ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(336, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 55;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(313, 59);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(86, 20);
            this.textBox4.TabIndex = 56;
            this.textBox4.Text = "Como siempre";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(313, 137);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(70, 20);
            this.textBox1.TabIndex = 57;
            this.textBox1.Text = "Nada";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(313, 111);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(70, 20);
            this.textBox2.TabIndex = 58;
            this.textBox2.Text = "Sólo un poco";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(313, 87);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(99, 20);
            this.textBox3.TabIndex = 59;
            this.textBox3.Text = "No lo bastante";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(418, 61);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(36, 20);
            this.textBox5.TabIndex = 60;
            this.textBox5.Text = "0";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(418, 87);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(36, 20);
            this.textBox6.TabIndex = 61;
            this.textBox6.Text = "1";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(418, 111);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(36, 20);
            this.textBox7.TabIndex = 62;
            this.textBox7.Text = "2";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(418, 137);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(38, 20);
            this.textBox8.TabIndex = 63;
            this.textBox8.Text = "3";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(313, 187);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(157, 20);
            this.textBox9.TabIndex = 64;
            this.textBox9.Text = "Al igual que siempre lo hice ";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(313, 265);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(86, 20);
            this.textBox10.TabIndex = 65;
            this.textBox10.Text = "Nunca";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(313, 239);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(86, 20);
            this.textBox11.TabIndex = 66;
            this.textBox11.Text = "Casi nunca ";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(313, 213);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(86, 20);
            this.textBox12.TabIndex = 67;
            this.textBox12.Text = "No tanto ahora";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(476, 187);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(36, 20);
            this.textBox13.TabIndex = 68;
            this.textBox13.Text = "0";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(476, 213);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(36, 20);
            this.textBox14.TabIndex = 69;
            this.textBox14.Text = "1";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(476, 239);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(36, 20);
            this.textBox15.TabIndex = 70;
            this.textBox15.Text = "2";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(476, 265);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(38, 20);
            this.textBox16.TabIndex = 71;
            this.textBox16.Text = "3";
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(190, 308);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(157, 20);
            this.textBox17.TabIndex = 72;
            this.textBox17.Text = "Casi siempre";
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(190, 360);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(157, 20);
            this.textBox18.TabIndex = 73;
            this.textBox18.Text = "No muy a menudo";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(190, 334);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(157, 20);
            this.textBox19.TabIndex = 74;
            this.textBox19.Text = "A veces";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(190, 388);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(157, 20);
            this.textBox20.TabIndex = 75;
            this.textBox20.Text = "Nunca";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(363, 308);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(36, 20);
            this.textBox21.TabIndex = 76;
            this.textBox21.Text = "0";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(363, 334);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(36, 20);
            this.textBox22.TabIndex = 77;
            this.textBox22.Text = "1";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(363, 360);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(36, 20);
            this.textBox23.TabIndex = 78;
            this.textBox23.Text = "2";
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(363, 386);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(38, 20);
            this.textBox24.TabIndex = 79;
            this.textBox24.Text = "3";
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(690, 310);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(86, 20);
            this.textBox25.TabIndex = 80;
            this.textBox25.Text = "Nunca ";
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(690, 386);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(170, 20);
            this.textBox26.TabIndex = 81;
            this.textBox26.Text = "Por lo general, en todo momento";
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(690, 360);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(86, 20);
            this.textBox27.TabIndex = 82;
            this.textBox27.Text = "Muy a menudo";
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(690, 334);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(86, 20);
            this.textBox28.TabIndex = 83;
            this.textBox28.Text = "A veces ";
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(913, 305);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(36, 20);
            this.textBox29.TabIndex = 84;
            this.textBox29.Text = "0";
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(913, 334);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(36, 20);
            this.textBox30.TabIndex = 85;
            this.textBox30.Text = "1";
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(913, 360);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(36, 20);
            this.textBox31.TabIndex = 86;
            this.textBox31.Text = "2";
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(913, 386);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(38, 20);
            this.textBox32.TabIndex = 87;
            this.textBox32.Text = "3";
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(735, 56);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(173, 20);
            this.textBox33.TabIndex = 88;
            this.textBox33.Text = "Me preocupo al igual que siempre";
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(735, 87);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(194, 20);
            this.textBox34.TabIndex = 89;
            this.textBox34.Text = "Podría tener un poco más de cuidado";
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(735, 113);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(194, 20);
            this.textBox35.TabIndex = 90;
            this.textBox35.Text = "No me preocupa tanto como debería";
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(735, 139);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(86, 20);
            this.textBox36.TabIndex = 91;
            this.textBox36.Text = "Totalmente";
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(971, 54);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(36, 20);
            this.textBox37.TabIndex = 92;
            this.textBox37.Text = "0";
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(971, 80);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(36, 20);
            this.textBox38.TabIndex = 93;
            this.textBox38.Text = "1";
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(971, 113);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(36, 20);
            this.textBox39.TabIndex = 94;
            this.textBox39.Text = "2";
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(971, 139);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(38, 20);
            this.textBox40.TabIndex = 95;
            this.textBox40.Text = "3";
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(756, 265);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(92, 20);
            this.textBox41.TabIndex = 96;
            this.textBox41.Text = "Nada";
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(756, 234);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(311, 20);
            this.textBox42.TabIndex = 97;
            this.textBox42.Text = "Mucho menos de lo qu aostumbraba";
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(756, 208);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(173, 20);
            this.textBox43.TabIndex = 98;
            this.textBox43.Text = "Menos de lo que acostumbraba";
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(756, 187);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(173, 20);
            this.textBox44.TabIndex = 99;
            this.textBox44.Text = "Igual que siempre";
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(1093, 182);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(36, 20);
            this.textBox45.TabIndex = 100;
            this.textBox45.Text = "0";
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(1093, 208);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(36, 20);
            this.textBox46.TabIndex = 101;
            this.textBox46.Text = "1";
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(1093, 234);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(36, 20);
            this.textBox47.TabIndex = 102;
            this.textBox47.Text = "2";
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(1091, 260);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(38, 20);
            this.textBox48.TabIndex = 103;
            this.textBox48.Text = "3";
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(1353, 139);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(173, 20);
            this.textBox49.TabIndex = 104;
            this.textBox49.Text = "Rara vez ";
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(1353, 111);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(173, 20);
            this.textBox50.TabIndex = 105;
            this.textBox50.Text = "No muy a menudo";
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(1353, 80);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(173, 20);
            this.textBox51.TabIndex = 106;
            this.textBox51.Text = "A veces";
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(1353, 51);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(173, 20);
            this.textBox52.TabIndex = 107;
            this.textBox52.Text = "A menudo";
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(1532, 49);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(36, 20);
            this.textBox53.TabIndex = 108;
            this.textBox53.Text = "0";
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(1532, 80);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(36, 20);
            this.textBox54.TabIndex = 109;
            this.textBox54.Text = "1";
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(1532, 111);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(36, 20);
            this.textBox55.TabIndex = 110;
            this.textBox55.Text = "2";
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(1532, 139);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(38, 20);
            this.textBox56.TabIndex = 111;
            this.textBox56.Text = "3";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "1",
            "1",
            "2",
            "3"});
            this.comboBox1.Location = new System.Drawing.Point(333, 160);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 112;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.comboBox2.Location = new System.Drawing.Point(313, 414);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 113;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.comboBox3.Location = new System.Drawing.Point(418, 289);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 21);
            this.comboBox3.TabIndex = 114;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.comboBox4.Location = new System.Drawing.Point(886, 414);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(121, 21);
            this.comboBox4.TabIndex = 115;
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.comboBox5.Location = new System.Drawing.Point(1041, 289);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(121, 21);
            this.comboBox5.TabIndex = 116;
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.comboBox6.Location = new System.Drawing.Point(946, 165);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(121, 21);
            this.comboBox6.TabIndex = 117;
            // 
            // comboBox7
            // 
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.comboBox7.Location = new System.Drawing.Point(1494, 181);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(121, 21);
            this.comboBox7.TabIndex = 118;
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(1278, 234);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(183, 20);
            this.textBox57.TabIndex = 119;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1329, 211);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 120;
            this.label3.Text = "RESULTADO";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1704, 470);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox57);
            this.Controls.Add(this.comboBox7);
            this.Controls.Add(this.comboBox6);
            this.Controls.Add(this.comboBox5);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox56);
            this.Controls.Add(this.textBox55);
            this.Controls.Add(this.textBox54);
            this.Controls.Add(this.textBox53);
            this.Controls.Add(this.textBox52);
            this.Controls.Add(this.textBox51);
            this.Controls.Add(this.textBox50);
            this.Controls.Add(this.textBox49);
            this.Controls.Add(this.textBox48);
            this.Controls.Add(this.textBox47);
            this.Controls.Add(this.textBox46);
            this.Controls.Add(this.textBox45);
            this.Controls.Add(this.textBox44);
            this.Controls.Add(this.textBox43);
            this.Controls.Add(this.textBox42);
            this.Controls.Add(this.textBox41);
            this.Controls.Add(this.textBox40);
            this.Controls.Add(this.textBox39);
            this.Controls.Add(this.textBox38);
            this.Controls.Add(this.textBox37);
            this.Controls.Add(this.textBox36);
            this.Controls.Add(this.textBox35);
            this.Controls.Add(this.textBox34);
            this.Controls.Add(this.textBox33);
            this.Controls.Add(this.textBox32);
            this.Controls.Add(this.textBox31);
            this.Controls.Add(this.textBox30);
            this.Controls.Add(this.textBox29);
            this.Controls.Add(this.textBox28);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.textBox25);
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button2);
            this.Name = "Form3";
            this.Text = "Evaluación Mental Depresión";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.Label label3;
    }
}